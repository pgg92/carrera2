--EJERCICIO5
CREATE OR REPLACE TRIGGER ejercicio5 before
  UPDATE OF estado ON material FOR EACH row
  
  DECLARE auxdescripcion tipo.descripcion%type;
  
  BEGIN
    SELECT descripcion
    INTO auxdescripcion
    FROM tipo
    WHERE tipo.codtipo = :new.tipo;
    
    IF :new.tipo = 'pesimo' AND :old.tipo = 'optimo' THEN
      raise_appplication_error('El material ' || :new.codigo ||' que es ' 
        || auxdescripcion ||' ha pasado directamente directamente                              
        de optimo a pesimo. Estudiar el deterioro' );
    END IF;
  END;
