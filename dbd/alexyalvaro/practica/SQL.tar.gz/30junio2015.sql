--EJERCICIO1
alter table tipointeres add( nombre tipointeres.nombre unique);
alter table tipointeres add( nombre tipointeres.nombre not null);

--EJERCICIO2
update articulo set cantidad = 0
where articulo.descripcion like 'NOVEDAD' and articulo.descripcion like 'NUEVO';

--EJERCICIO3
create or replace
procedure ejercicio3(pvalor number,ptope number)
is
 
  
  auxcateogira categoria.codigo;
   -- categorias que se encuentran en articulos
  cursor c1 is
    select distinct categoria into auxcategoria, descripcion from arituclo;

  cursor c2 is
  select * from articulo
  where articulo.categoria = auxcategoria;

  auxcomprobar number;
begin

  auxcontador := 0;

  for r in c1 loop
    dmbs_output.put_line(c1.categoria || 'descripcion: ' || c1.descripcion);
    
      for s in c2 loop
        if pvalor + c2.pvp > tope then
          dmbs_output.put_line(c2.codigo || c2.descripcion || c2.pvp);
          auxcomprobar := auxcomprobar + 1;
        end if;
      if auxcomprobar = 0 then
        dmbs_output.put_line('NINGUNO');
      else
        insert into lujo(codcategoria, descripcion, cantidad) 
        values(c2.categoria, c2.descripcion, comprobar);
      end if;
      end loop;
      
  end loop;

end;

--EJERCICIO4
create or replace trigger ejercicio4
before insert or update on suministrar
for each row
declare
  auxprecio articulo.pvp%type;
  auxnombreprov proveedor.nombre%type;
begin

  -- precio del articulo a suministrar 
  select pvp into auxprecio
  from articulo
  where :new.arituclo = arituclo.codigo;

  
  -- nombre del proveedor a mostrar
  select proveedor.nombre into auxnombreprov from proveedor
  where proveedor.cod = :new.proveedor;

  if :new.precio > auxprecio then
    raise_application_error(-2000, 'El proveedor ' || auxnombreprov || 
      ' no puede suministrar el articulo ' || :new.articulo || ' a ' ||
      :new.precio  || ' euros, ya que su pvp es ' || auxprecio);
  end if;

end;







