--EJERCICIO6
CREATE OR REPLACE TRIGGER ejercicio6 before
  INSERT ON padecer FOR EACH row DECLARE nombre enfermedad.nombre%type;
  anyoAparece NUMBER;
  cuantos     NUMBER;
  nombreAnimal animal.nombre%type;
  BEGIN
    SELECT nombre INTO nombre FROM enfermedad WHERE codigo = :new.enfermedad;
    SELECT anyoAparece
    INTO anyoAparece
    FROM enfermedad
    WHERE codigo   = :new.enfermedad;
    IF anyoAparece = TO_CHAR(sysdate, 'YYYY') THEN
      raise_application_error(-20000, 'la enfermedad' || enfermedad ||'es nueva');
    ELSE
      IF :new.maxtemperatura < 40 THEN
        SELECT COUNT(*) INTO cuantos FROM termica WHERE enfermedad = :new.enfermedad;
        IF cuantos = 1 THEN
          SELECT nombre INTO nombreAnimal FROM animal WHERE codigo = :new.animal.codigo;
          escribir('El animal' || nombreAnimal || ' todavia puede tener fiebre mas alta');
        ELSE
          :new.maxtemperatura > 40 THEN
          BEGIN
          EXCEPTION
          WHEN dup_val_on_index THEN
            NULL;
          END;
        END IF;
      END IF;
    END IF;
  END;