﻿using NUnit.Framework;
using System;

namespace HadaTest
{
	[TestFixture ()]
	public class NUnitTestProximitySensor
	{
	    private bool proxCondition1 = false;
		private bool proxCondition2 = false;


		private void onProximity1 (System.Object sender, Hada.ProximityArgs pa) {
			proxCondition1 = true;
		}

		private void onProximity2 (System.Object sender, Hada.ProximityArgs pa) {
			proxCondition2 = true;
		}

		private void onProximity3 (System.Object sender, Hada.ProximityArgs pa) {
		}

		[Test ()]
		public void TestName () 
		{
			Hada.ProximitySensor ps = new Hada.ProximitySensor ("testProximitySensor", 100, 20);
			Assert.AreEqual (ps.name, "testProximitySensor");
		}

		[Test ()]
		public void TestProximityConditionEvent () 
		{
			Hada.ProximitySensor ps1 = new Hada.ProximitySensor ("testProximitySensor", 100, 20);
			ps1.proximityCondition += onProximity1;

			proxCondition1 = false;
			ps1.proximity = 10;
			Assert.IsTrue (proxCondition1);

			Hada.ProximitySensor ps2 = new Hada.ProximitySensor ("testProximitySensor", 100, 20);
			ps2.proximityCondition += onProximity2;

			proxCondition2 = false;
			ps2.proximity = 50;
			Assert.IsFalse (proxCondition2);
		}

		[Test ()]
		public void TestProximityAfterProximityConditionEvent () 
		{
			Hada.ProximitySensor ps = new Hada.ProximitySensor ("testProximitySensor", 100, 20);
			ps.proximityCondition += onProximity3;

			ps.proximity = 10;
			Assert.AreEqual (ps.proximity, 10);
		}
	}
}

