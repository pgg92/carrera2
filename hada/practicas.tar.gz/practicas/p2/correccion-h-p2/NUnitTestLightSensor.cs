﻿using NUnit.Framework;
using System;

namespace HadaTest
{
	[TestFixture ()]
	public class NUnitTestLightSensor
	{
		private bool lowLight1 = false;
		private bool lowLight2 = false;
		private bool highLight1 = false;
		private bool highLight2 = false;

		private void onLowLight1 (System.Object sender, Hada.LowLightArgs lla) {
			lowLight1 = true;
		}

		private void onLowLight2 (System.Object sender, Hada.LowLightArgs lla) {
			lowLight2 = true;
		}

		private void onLowLight3 (System.Object sender, Hada.LowLightArgs lla) {
		}

		private void onHighLight1 (System.Object sender, Hada.HighLightArgs hla) {
			highLight1 = true;
		}

		private void onHighLight2 (System.Object sender, Hada.HighLightArgs hla) {
			highLight2 = true;
		}

		private void onHighLight3 (System.Object sender, Hada.HighLightArgs hla) {
		}
			
		[Test ()]
		public void TestName () 
		{
			Hada.LightSensor ls = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			Assert.AreEqual ("testLightSensor", ls.name);
		}

		[Test ()]
		public void TestLowConditionEvent () 
		{
			Hada.LightSensor ls1 = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			ls1.lowLightCondition += onLowLight1;
			lowLight1 = false;
			ls1.level = 10;
			Assert.IsTrue (lowLight1);

			Hada.LightSensor ls2 = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			ls2.lowLightCondition += onLowLight2;
			lowLight2 = false;
			ls2.level = 50;
			Assert.IsFalse (lowLight2);
		}

		[Test ()]
		public void TestLevelAfterLowConditionEvent () 
		{
			Hada.LightSensor ls = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			ls.lowLightCondition += onLowLight3;
			ls.level = 10;
			Assert.AreEqual (ls.level, 10);
		}

		[Test ()]
		public void TestHighConditionEvent () 
		{
			Hada.LightSensor ls1 = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			ls1.highLightCondition += onHighLight1;
			highLight1 = false;
			ls1.level = 80;
			Assert.IsTrue (highLight1);

			Hada.LightSensor ls2 = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			ls2.highLightCondition += onHighLight2;
			highLight2 = false;
			ls2.level = 50;
			Assert.IsFalse (highLight2);
		}

		[Test ()]
		public void TestLevelAfterHighConditionEvent () 
		{
			Hada.LightSensor ls = new Hada.LightSensor ("testLightSensor", 50, 20, 70);
			ls.highLightCondition += onHighLight3;
			ls.level = 80;
			Assert.AreEqual (ls.level, 80);
		}
	}
}

