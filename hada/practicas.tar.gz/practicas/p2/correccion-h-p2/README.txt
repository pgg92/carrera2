Para poder usar los test deberéis añadir a MonoDevelop el framework de NUnit.
Aunque para una versión anterior de NUnit, tenéis una explicación de cómo
hacer esto en 
https://developer.xamarin.com/guides/cross-platform/deployment,_testing,_and_metrics/installing-nunit-using-nuget/

La versión usada para realizar las pruebas ha sido la 3.6.1

Tenéis más información sobre el uso de NUNit en
https://www.codeproject.com/Articles/34161/Setup-a-Test-Project-with-NUnit-and-MonoDevelop

