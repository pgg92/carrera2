﻿using NUnit.Framework;
using System;
using System.IO;

namespace HadaTest
{
	[TestFixture ()]
	public class NUnitTestRobot
	{
		private bool statusChanged1=false;
		private bool statusChanged2=false;

		private void robotStatusChanged1 (object sender, Hada.StatusChangeArgs e) {
			statusChanged1 = true;
		}

		private void robotStatusChanged2 (object sender, Hada.StatusChangeArgs e) {
			statusChanged2 = true;
		}

		private void robotStatusChanged3 (object sender, Hada.StatusChangeArgs e) {
		}

		[Test ()]
		public void TestName () 
		{
			Hada.Robot r = new Hada.Robot ("R2D2");
			Assert.AreEqual (r.name, "R2D2");
		}

		[Test ()]
		public void TestStatusChangedEvent () 
		{
			Hada.Robot r1 = new Hada.Robot ("R2D2");
			r1.on ();
			r1.statusChanged += robotStatusChanged1;
			statusChanged1 = false;
			r1.on ();
			Assert.IsTrue (statusChanged1);

			Hada.Robot r2 = new Hada.Robot ("R2D2");
			r2.on ();
			r2.statusChanged += robotStatusChanged2;
			statusChanged2 = false;
			r2.off ();
			Assert.IsTrue (statusChanged2);
		}

		[Test ()]
		public void TestCreateLowLightCondition () 
		{
			Hada.Robot r = new Hada.Robot ("R2D2");
			r.statusChanged += robotStatusChanged3;

			StringWriter sw = new StringWriter();
			Console.SetOut (sw);

			r.createLowLightCondition ();

			string[] lines = sw.ToString ().Split ('\n');
			Assert.GreaterOrEqual (lines.Length, 2);
			Assert.AreEqual (lines [0].ToLower (), "low-light alert!!");

			string[] fields = lines [1].Split (' ');
			Assert.GreaterOrEqual (fields.Length, 3);
			float level = float.Parse (fields [2]);
			Assert.Less(level, 20);
		}

		[Test ()]
		public void TestCreateHighLightCondition () 
		{
			Hada.Robot r = new Hada.Robot ("R2D2");
			r.statusChanged += robotStatusChanged3;
			
			StringWriter sw = new StringWriter();
			Console.SetOut (sw);			

			r.createHighLightCondition ();

			string[] lines = sw.ToString ().Split ('\n');
			Assert.GreaterOrEqual (lines.Length, 2);
			Assert.AreEqual (lines [0].ToLower (), "high-light alert!!");

			string[] fields = lines [1].Split (' ');
			Assert.GreaterOrEqual (fields.Length, 3);
			float level = float.Parse (fields [2]);
			Assert.Greater(level, 70);
		}

		[Test ()]
		public void TestCreateProximityCondition () 
		{		
			Hada.Robot r = new Hada.Robot ("R2D2");
			r.statusChanged += robotStatusChanged3;
			
			StringWriter sw = new StringWriter();
			Console.SetOut (sw);			

			r.createProximityCondition ();

			string[] lines = sw.ToString ().Split ('\n');
			Assert.GreaterOrEqual (lines.Length, 2);
			Assert.AreEqual (lines [0].ToLower (), "proximity alert!!");

			string[] fields = lines [1].Split (' ');
			Assert.GreaterOrEqual (fields.Length, 3);
			float level = float.Parse (fields [2]);
			Assert.Less(level, 20);
		}
	}
}

