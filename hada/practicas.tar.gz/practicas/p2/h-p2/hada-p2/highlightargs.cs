﻿using System;

namespace Hada
{
	public class HighLightArgs : EventArgs
	{
		private float l;

		public HighLightArgs (float l)
		{
			this.l = l;
		}

		public float level { get { return l; } }
	}
}

