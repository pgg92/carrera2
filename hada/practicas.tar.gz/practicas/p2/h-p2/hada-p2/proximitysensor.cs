﻿using System;

namespace Hada
{
	public class ProximitySensor:FlipFlop
	{
		private float actual;
		private float minimo;
		public ProximitySensor (string n , float p , float minp) : base(n)
		{
			actual = p;
			minimo = minp;
		}

		public float proximity
		{
			get{ return actual;}

			set{ 
				actual = value;

				  if (actual < minimo) {
					if (proximityCondition != null) {
						proximityCondition (this, new ProximityArgs (actual));
					}
				}
			}
			
		}

		public event EventHandler<ProximityArgs> proximityCondition;

	}
}

