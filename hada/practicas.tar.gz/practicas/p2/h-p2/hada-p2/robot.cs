﻿using System;

namespace Hada
{
	public class Robot:FlipFlop
	{
		private LightSensor ls;
		private ProximitySensor ps;

		public Robot (string name) : base(name) //usa la funcionalidad del constructor de flip flop
		{
			ls = new LightSensor ("Sensor light" , 50 ,20 ,70);
			ps = new ProximitySensor ("Sensor proximity" , 100 , 20);

			ps.proximityCondition += onProximity;
			ls.highLightCondition += onHighLight;
			ls.lowLightCondition += onLowLight;
		}

		public void on ()
		{
			status = Status.on;
		}

		public void off ()
		{
			status = Status.off;
		}

		public void createLowLightCondition ()
		{
			ls.level = int.MinValue;
		}

		public void createHighLightCondition ()
		{
			ls.level = int.MaxValue;

		}

		public void createProximityCondition ()
		{
			ps.proximity = int.MinValue;

		}

		private void onLowLight (object sender , LowLightArgs e)
		{
			LightSensor ls = (LightSensor) sender;
			Console.WriteLine ("low-light alert!!");
			Console.WriteLine ("light level {0}" , ls.level);
			
		}

		private void onHighLight (object sender , HighLightArgs e)
		{
			LightSensor ls = (LightSensor) sender;
			Console.WriteLine ("high-light alert!!");
			Console.WriteLine ("light level {0}" , ls.level);
		}

		private void onProximity (object sender , ProximityArgs e)
		{
			ProximitySensor ps = (ProximitySensor) sender;
			Console.WriteLine ("proximity alert!!");
			Console.WriteLine ("proximity level {0}" , ps.proximity);
		}
	}
}

