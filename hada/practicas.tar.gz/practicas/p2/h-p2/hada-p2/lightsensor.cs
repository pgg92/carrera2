﻿using System;

namespace Hada
{
	public class LightSensor:FlipFlop
	{
		private float actual;
		private float min;
		private float max;

		public LightSensor (string n , float l , float minl , float maxl) : base(n)
		{
			actual = l;
			min = minl;
			max = maxl;
		}

		public float level 
		{
			get{ return actual;}

			set{ 
				actual = value;

				if (actual > max) {
					if (highLightCondition != null) {
						highLightCondition (this, new HighLightArgs (actual));
					}
				} 

				else if (actual < min) {
					if (lowLightCondition != null) {
						lowLightCondition (this, new LowLightArgs (actual));
					}
				}

				else {
				}
			}

		}

		public event EventHandler<LowLightArgs> lowLightCondition ;


		public event EventHandler<HighLightArgs> highLightCondition;

	}
}

