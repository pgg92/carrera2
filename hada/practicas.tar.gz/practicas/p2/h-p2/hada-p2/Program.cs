﻿using System;

namespace Hada
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Robot r = new Robot ("Hada");

			r.createHighLightCondition ();
			r.createLowLightCondition ();
			r.createProximityCondition ();
		}
	}
}
