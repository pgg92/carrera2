﻿using System;

namespace Hada
{
	public class LowLightArgs : EventArgs
	{
		private float l;

		public LowLightArgs (float l)
		{
			this.l = l;
		}

		public float level { get { return l; } }
	}
}
