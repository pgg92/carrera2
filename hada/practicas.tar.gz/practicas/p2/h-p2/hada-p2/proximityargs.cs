﻿using System;

namespace Hada
{
	public class ProximityArgs : EventArgs
	{
		private float l;

		public ProximityArgs (float l)
		{
			this.l = l;
		}

		public float proximity { get { return l; } }
	}
}

