
namespace Domos
{
    class Light : FlipFlop {
        public Light (string n) : base (n) {
            System.Console.WriteLine ("Light built.");
        }
    }
}
