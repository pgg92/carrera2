namespace Domos {
    using System;
    
    public class App {
        public App() {
        }

        ~App() {
        }
        
        static void Main(string[] args) {
            
            House h = new House (8, 5);
            Console.WriteLine ("App. started.");

            h.showAssets ();
        }
    }
}
        
