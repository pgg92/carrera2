﻿using System;
using Gtk; 
using CAD;
using EN;

namespace GUI{
	public class CadActions
	{
		private static DataBase ddbb;
		//public string clientes = {"","","","","","","","",""};
		public CadActions ()
		{ 
			//ESTE METODO NO HARA NAAADAAAA


			/*cmd.Execute¿New?Query()
			*
			*SqliteDataReader dr = cmd.ExecuteReader();
			*
			*while(dr.Read()) [TRUE/FALSE]
			*
			*	...... = dr["id"];
			*/
		}

		public static void createAndPopulateDB(string dbfn = "")
		{
			Client clientes;
			Product productos;
			Random rnd = new Random();
			int numCli;
			int numPro;

			ddbb = new DataBase (dbfn,DataBase.Creation.YES);
			if (!ddbb.isOpen)
				ddbb.openConnection ();
			
			numCli = rnd.Next(1,20);
			numPro = rnd.Next(1,5);

			for (int i = 0; i < numCli; i++) {
				clientes = new Client (i + 1,("NombrePredeterminado"+(i+1).ToString()),("Dir"+(i+1).ToString()).ToString(),("City"+(i+1).ToString()).ToString());
				
				for (int j = 0; j < numPro; j++) {
				//	productos = new Product (j + 1,clientes.id,"NombreProdctPred",12.34);
					//clientes.addProduct (productos);
				}
				clientes.save (dbfn);
			}
			ddbb.closeConnection ();
		}
	
	}
}