﻿using System;
using Gtk;

namespace hp3{

	public partial class MainWindow: Gtk.Window
	{
		private static CAD.CADClient ca;
		private string dbfn;
	
		public MainWindow (string dbfn = "basedatos.db") : base (Gtk.WindowType.Toplevel)
		{
			this.dbfn = dbfn;
			createAndPopulateDB (dbfn);
			ca = new CAD.CADClient (dbfn);
			
			Build ();
		}

		public void createAndPopulateDB (string dbfn){
			GUI.CadActions.createAndPopulateDB (dbfn);
		}

		protected void createClient (object sender, EventArgs e){
			EN.Client cl = new EN.Client (int.Parse(entryid.Text.ToString()), entryname.Text.ToString(), entryaddress.Text.ToString(), entrycity.Text.ToString());

			//Console.WriteLine(cl.ToString("TEST_CLIENT:"));
			
				try {
				if (entryid.Text != null && int.Parse(entryid.Text.ToString()) > 0) {
					cl.save(dbfn);
				}
			} catch (Exception ex) {
				Console.WriteLine ("Error creando cliente:");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
		}

		protected void readClient (object sender, EventArgs e){
			EN.Client cl;

			try {
				if (entryid.Text != null && int.Parse(entryid.Text.ToString()) > 0) {
					cl = (EN.Client)ca.read (int.Parse(entryid.Text.ToString()));
					//Console.WriteLine(cl.ToString("Client: "));
					entryid.Text=cl.id.ToString();
					entryname.Text=cl.name.ToString();
					entryaddress.Text=cl.address.ToString();
					entrycity.Text=cl.city.ToString();
					//labelnop.Text=ca.numberOfProducts(cl.id).ToString();
				}
			} catch (Exception ex) {
				Console.WriteLine ("Error leyendo cliente:");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
		}

		protected void updateClient (object sender, EventArgs e){
			EN.Client cl = new EN.Client (int.Parse(entryid.Text.ToString()), entryname.Text.ToString(), entryaddress.Text.ToString(), entrycity.Text.ToString());

			try {
				if (entryid.Text != null && int.Parse(entryid.Text.ToString()) > 0) {
					ca.update (cl);
					cl = (EN.Client)ca.read (int.Parse(entryid.Text.ToString()));
					//Console.WriteLine(cl.ToString("NOW: "));

				}
			} catch (Exception ex) {
				Console.WriteLine ("Error actualizando cliente:");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
		}

		protected void deleteClient (object sender, EventArgs e)
		{
			try {
				if (entryid.Text != null && int.Parse(entryid.Text.ToString()) > 0) {
					ca.delete (int.Parse(entryid.Text.ToString()));
					entryid.Text="0";
					entryname.Text="";
					entryaddress.Text="";
					entrycity.Text="";
				}
			} catch (Exception ex) {
				Console.WriteLine ("Error borrando cliente:");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
		}


		protected void prevClient (object sender, EventArgs e)
		{
			EN.Client cl;

			try {
				if (entryid.Text != null && int.Parse(entryid.Text.ToString()) > 1) {
					cl = (EN.Client)ca.read (int.Parse(entryid.Text.ToString())-1);

					entryid.Text=cl.id.ToString();
					entryname.Text=cl.name.ToString();
					entryaddress.Text=cl.address.ToString();
					entrycity.Text=cl.city.ToString();
				}
			} catch (Exception ex) {
				Console.WriteLine ("Error leyendo cliente:");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
		}

		protected void nextClient (object sender, EventArgs e)
		{
			EN.Client cl;

			try {
				if (entryid.Text != null && int.Parse(entryid.Text.ToString()) > 0) {
					cl = (EN.Client)ca.read (int.Parse(entryid.Text.ToString())+1);
					if(cl.id!=0){
						entryid.Text=cl.id.ToString();
						entryname.Text=cl.name.ToString();
						entryaddress.Text=cl.address.ToString();
						entrycity.Text=cl.city.ToString();
					}
				}
			} catch (Exception ex) {
				Console.WriteLine ("Error leyendo cliente:");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
		}
		protected void updateNumberOfProducts (int id)
		{
			
		}
		protected void OnDeleteEvent (object sender, DeleteEventArgs a)
		{
			Application.Quit ();
			a.RetVal = true;
		}

		protected void OnButtonupdateClicked (object sender, EventArgs e)
		{
			updateClient (sender, e);
		}

		protected void OnButtonfinishClicked (object sender, EventArgs e)
		{
			Application.Quit ();
		}

		protected void OnButtoncreateClicked (object sender, EventArgs e)
		{
			createClient (sender, e);
		}

		protected void OnButtonreadClicked (object sender, EventArgs e)
		{
			readClient (sender, e);
		}

		protected void OnButtondeleteClicked (object sender, EventArgs e)
		{
			deleteClient (sender, e);
		}

		protected void OnButtonprevClicked (object sender, EventArgs e)
		{
			prevClient (sender, e);
		}

		protected void OnButtonnextClicked (object sender, EventArgs e)
		{
			nextClient (sender, e);
		}
	}
}
