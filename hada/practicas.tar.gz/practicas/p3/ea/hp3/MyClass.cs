﻿using System;

namespace hp3
{
	public class MyClass
	{
		public MyClass ()
		{
			/*SOLO AQUI SOLICITARE INFORMACION A LAS BASES DE DATOS
			// SI HAY QUE CREAR LA BASE DE DATOS (CONSTRUCTOR EN database.cs):
			// SqlConnection.CreateFile(FileName);
			//createClientTable();
			//createProductTable();
			//System.Data.ConnectionState.Open(); Para saber si esta abierta (bool)
			
			

	
			*/
		}
		
	}
}

