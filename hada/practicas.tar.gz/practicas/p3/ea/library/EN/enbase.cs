﻿using System;

namespace EN
{
	public interface ENBase {
		int id { get; set; }
		string ToString ();
	}
}

