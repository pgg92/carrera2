﻿using System;
using System.Collections.Generic;

namespace EN
{
	public class Client : ENBase
	{
		public Client (int id, string name = "", string address = "", string city = ""){
			this.id = id;
			this.name = name;
			this.address = address;
			this.city = city;
		}

		public string name { get; set; }
		public string address { get; set; }
		public string city { get; set; }
		public int id { get; set; }
		public List<Product> products { get{ return products; } }

		public void addProduct (Product p){
		/*	: Añade el producto p a la lista de productos
		comprados por este cliente.*/
			products.Add (p);
		}
		public void removeProduct (Product p){
		/*	: Elimina el producto p de la lista de productos
		comprados por este cliente.*/
			products.Remove (p);
		}

		public void save (string dbname){
		/*	: Guarda este cliente en la BB.DD. almacenada en el
		fichero con nombre dbname. Para ellos hará uso de los métodos apropiados de
		CAD.CADClient.*/
			CAD.CADClient aux = new CAD.CADClient (dbname);
			aux.create (this);
			
		}

		public string ToString(string texto){
			if (texto == "")
				texto = "Cliente: ";
			String text = texto + "\n\tID: " + id.ToString() + "\n\tName: " + name.ToString () + "\n\tAddress: " + address.ToString () + "\n\tCity: " + city.ToString ();
			return text;
		}
	}
}

