﻿using System;
using Mono.Data.Sqlite;
using System.Data;


namespace CAD
{
	public class CADClient : CAD
	{
		private DataBase ddbb;

		public CADClient (string db){
		/*	: Crea la BB.DD. que se corresponde con el fichero
		llamado db.*/
			ddbb = new DataBase (db);
			if (!ddbb.isOpen)
				ddbb.openConnection ();
		}

		~CADClient (){
		/*: Cierra la conexión con la BB.DD.*/
			if (ddbb.isOpen)
				ddbb.closeConnection ();
		}

		public void create (EN.ENBase en){
		/*	: Crea un nuevo cliente en la BB.DD. con los datos
		del cliente representado por el parámetro EN y si no se puede capturará la excepción de tipo
		SqliteException y mostrará en el terminal la cadena “Client create failed.\nError:
		” seguida de la cadena que describe el error.*/
			
			EN.Client aux = (EN.Client)en;

			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();
				
				using (SqliteCommand cmd = new SqliteCommand (ddbb.connection)) {
					// CREATE
					cmd.CommandText = @"INSERT INTO clients VALUES (" + aux.id.ToString() +",'"+ aux.name.ToString() +"','"+ aux.address.ToString() +"','"+ aux.city.ToString() +"')";
					cmd.ExecuteNonQuery();

					/*@"CREATE TABLE clients (id INTEGER PRIMARY KEY, name TEXT, 
				                    address TEXT, city TEXT)"*/
				}

			} catch (SqliteException ex) { 
				Console.WriteLine ("Client create failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());

			}
		}

		public EN.ENBase read (int id){
		/*	: Devuelve el cliente leído de la BB.DD. con id == id y
		si no se puede capturará la excepción de tipo SqliteException y mostrará en el terminal la
		cadena “Client read failed.\nError: ” seguida de la cadena que describe el error.
		Proyecto library: CAD:cadclient.cs II*/
			int aux;

			//IMPLEMENTAR...
			EN.Client cl = new EN.Client(0);

			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				string stm = "SELECT * FROM clients";

				using (SqliteCommand cmd = new SqliteCommand (stm,ddbb.connection)) {

					using (SqliteDataReader dr = cmd.ExecuteReader()) {

						while (dr.Read()) {
							aux = int.Parse(dr["id"].ToString());
							if (id == aux){
								cl = new EN.Client(int.Parse(dr["id"].ToString()),dr["name"].ToString(),dr["address"].ToString(),dr["city"].ToString());
							}
						}
						dr.Close();
					}

					cmd.ExecuteNonQuery();
				}
				ddbb.closeConnection();

			} catch (SqliteException ex) { 
				Console.WriteLine ("Client read failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
			return cl;
		}

		public void update (EN.ENBase en){
		/*	: Actualiza los datos de un cliente en la BB.DD. con
		los datos del cliente representado por el parámetro en y si no se puede capturará la
		excepción de tipo SqliteException y mostrará en el terminal la cadena “Client update
		failed.\nError: ” seguida de la cadena que describe el error.*/
			EN.Client aux = (EN.Client)en;
			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();
				
				using (SqliteCommand cmd = new SqliteCommand (ddbb.connection)) {
					// CREATE
					cmd.CommandText = @"UPDATE clients SET name = '" + aux.name.ToString()+ "', address = '"+ aux.address.ToString() + "', city = '"+ aux.city.ToString()+"' " +
						"WHERE id == '"+ aux.id.ToString() +"'";
					cmd.ExecuteNonQuery();

					/*@"CREATE TABLE clients (id INTEGER PRIMARY KEY, name TEXT, 
				                    address TEXT, city TEXT)"*/
				}

			} catch (SqliteException ex) { 
				Console.WriteLine ("Client update failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());

			}

		}
	
		public void delete (int id){
		/*	: Borra el cliente de la BB.DD. con id == id y si no se
		puede capturará la excepción de tipo SqliteException y mostrará en el terminal la cadena
		“Client delete failed.\nError: ” seguida de la cadena que describe el error.*/
			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				using (SqliteCommand cmd = new SqliteCommand (ddbb.connection)) {
					// CREATE
					cmd.CommandText = @"DELETE FROM clients WHERE id == '"+ id.ToString() +"'";
					cmd.ExecuteNonQuery();

					/*@"CREATE TABLE clients (id INTEGER PRIMARY KEY, name TEXT, 
				                    address TEXT, city TEXT)"*/
				}

			} catch (SqliteException ex) { 
				Console.WriteLine ("Client update failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());

			}
		}

		public int numberOfProducts (int id){
		/*	: Devuelve el número de productos comprados
		por el cliente con id == id y si no se puede capturará la excepción de tipo
		SqliteException y mostrará en el terminal la cadena “Client numberOfProducts
		failed.\nError: ” seguida de la cadena que describe el error.*/
			int aux = 0;
			/*
			//IMPLEMENTAR...
			EN.Client cl = new EN.Client(0);

			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				string stm = "SELECT * FROM products";

				using (SqliteCommand cmd = new SqliteCommand (stm,ddbb.connection)) {

					using (SqliteDataReader dr = cmd.ExecuteReader()) {

						while (dr.Read()) {
							if (id == int.Parse(dr["cid"].ToString())){
								aux++;
							}
						}
						dr.Close();
					}

					cmd.ExecuteNonQuery();
				}
				ddbb.closeConnection();

			} catch (SqliteException ex) { 
				Console.WriteLine ("Client numberOfProducts failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}*/
			return aux;
		}
	}
}

