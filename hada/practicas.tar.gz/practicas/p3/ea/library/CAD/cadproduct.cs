﻿using System;
using Mono.Data.Sqlite;
using System.Data;

namespace CAD
{
	public class CADProduct : CAD
	{
		private DataBase ddbb;

		public CADProduct(string db){
			/*Abrir la base de datos*/
			ddbb = new DataBase (db);
			if (!ddbb.isOpen)
				ddbb.openConnection ();
		}
		
		~CADProduct (){
			/*: Cierra la conexión con la BB.DD.*/
			if (ddbb.isOpen)
				ddbb.closeConnection ();
		}

		public void create (EN.ENBase en){

			EN.Product aux = (EN.Product)en;

			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				using (SqliteCommand cmd = new SqliteCommand (ddbb.connection)) {
					// CREATE
					cmd.CommandText = @"INSERT INTO products VALUES (" + aux.id.ToString() +"','"+ aux.description.ToString() +"','"+ aux.price.ToString() +",'"+ aux.cid.ToString() +"')";
					cmd.ExecuteNonQuery();
				}

			} catch (SqliteException ex) { 
				Console.WriteLine ("Product create failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());

			}
		}

		public EN.ENBase read (int id){
			int aux;

			EN.Product cl = new EN.Product(0);

			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				string stm = "SELECT * FROM products";

				using (SqliteCommand cmd = new SqliteCommand (stm,ddbb.connection)) {

					using (SqliteDataReader dr = cmd.ExecuteReader()) {
						//READING
						while (dr.Read()) {
							aux = int.Parse(dr["id"].ToString());
							if (id == aux){
								cl = new EN.Product(int.Parse(dr["id"].ToString()),int.Parse(dr["clientid"].ToString()),dr["description"].ToString(),double.Parse(dr["price"].ToString()));
							}
							
						}
						dr.Close();
					}

					cmd.ExecuteNonQuery();
				}
				ddbb.closeConnection();

			} catch (SqliteException ex) { 
				Console.WriteLine ("Product read failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());
			}
			return cl;
		}

		public void update (EN.ENBase en){
			EN.Product aux = (EN.Product)en;
			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				using (SqliteCommand cmd = new SqliteCommand (ddbb.connection)) {
					// UPDATE
					cmd.CommandText = @"UPDATE products SET description = '"+ aux.description.ToString() + "', price = '"+ aux.price.ToString()+"', clientid = '" + aux.cid.ToString() + 
						"WHERE id == '"+ aux.id.ToString() +"'";
					cmd.ExecuteNonQuery();
				}

			} catch (SqliteException ex) { 
				Console.WriteLine ("Product update failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());

			}

		}

		public void delete (int id){
			try {
				if(!ddbb.isOpen)
					ddbb.openConnection();

				using (SqliteCommand cmd = new SqliteCommand (ddbb.connection)) {
					// CREATE
					cmd.CommandText = @"DELETE FROM products WHERE id == '"+ id.ToString() +"'";
					cmd.ExecuteNonQuery();

				}

			} catch (SqliteException ex) { 
				Console.WriteLine ("Product update failed.");
				Console.WriteLine ("Error: {0}", ex.ToString ());

			}
		}
	}
}

