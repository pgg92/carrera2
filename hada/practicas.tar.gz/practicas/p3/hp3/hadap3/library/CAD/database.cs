﻿using System;

namespace CAD
{
	public class Database
	{
		public Database ()
		{
		}

		public enum Creation {NO,YES}
		public SqliteConnection connection {get {return con; }}
		public Database(string fname, Creation create = Creation.NO){}
		~Database:

		private void createClientTable(){}
		private void createProducTable (){}

		public void openConnection(){}
		public void closeConnection(){}

		public bool isOpen(){}
	}
}

