﻿using System;

namespace CAD
{
	public class CADclient
	{
		public CADclient ()
		{
		}

		public CADclient(string db){}

		~CADclient (){}

		public void create (EN.ENBase en){}
		public EN.ENBase read (int id){}

		public void update (EN.ENBase en){}
		public void delete(int id){}
		public int numberOfProducts(int id){}

	}
}

