﻿using System;

namespace CAD
{
	public class CADproduct
	{
		public CADproduct ()
		{
		}

		public CADproduct(string db){}
		~CADproduct(){}
		public void create (EN.ENBase en){}
		public EN.ENbase read (int id){}
		public void update (EN.ENBase en){}
		public void delete (int id){}
	}
}

