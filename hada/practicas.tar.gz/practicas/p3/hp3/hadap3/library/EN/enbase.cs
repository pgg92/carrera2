﻿using System;

namespace EN
{
	public class ENbase
	{
		public ENbase ()
		{
		}

		public interface ENBase{

			int id {get; set;}
			string ToString ();
		}
	}
}

