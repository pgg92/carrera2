﻿using System;

namespace EN
{
	public class client
	{
		public client ()
		{
		}

		public client (int id, string name = "", string addres = "", string city = ""){}
		public string name { get; set;}
		public string addres { get; set;}
		public string city { get; set;}
		public int id { get; set;}

		public void addProduct (Product p){}
		public void removeProduct (Product p){}
		public ObjectDisposedException save (string dbname){}
	

	}
}

