﻿using System;

namespace EN
{
	public class Product
	{
		public Product ()
		{
		}

		public Product(int id, int cid = 0, string description = "", double price = 0.0){}
		public string description { get; set;}
		public double price { get; set;}
		public int cid {get;set;}
		public int id { get; set;}
		public void save (string dbname){}
	}
}

