﻿using System;

namespace library
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

