﻿using System;

namespace hp3
{
	public class cadactions
	{
		public cadactions (){}

		public static void createAndPopulateDB(string dbfn)
		{
			
		}


	}
}

