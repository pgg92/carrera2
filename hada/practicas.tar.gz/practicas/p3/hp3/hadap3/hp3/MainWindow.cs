﻿using System;
using Gtk;

public partial class MainWindow: Gtk.Window
{
	public MainWindow () : base (Gtk.WindowType.Toplevel)
	{
		Build ();
	}

	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}

	public MainWindow(string dbfn = "")
	{
		
	}

	public void createAndPopulateDB(string dfbfn)
	{


	}

	protected void createClient(object sender, EventArgs e)
	{


	}

	protected void readClient(object sender, EventArgs e)
	{
	
	}

	protected void updateClient(object sender, EventArgs e)
	{
		
	}

	protected void readClient(object sender, EventArgs e)
	{
		
	}

	protected void updateClient(object sender, EventArgs e)
	{
		
	}

	protected void deleteClient(object sender, EventArgs e)
	{
		
	}

	protected void prevClient(object sender, EventArgs e)
	{
		
	}

	protected void nextClient(object sender, EventArgs e)
	{
		
	}

	protected void updateNumberOfProducts(int id)
	{
		
	}
}

















