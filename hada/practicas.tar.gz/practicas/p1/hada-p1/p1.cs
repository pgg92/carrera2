using System;

class HadaP1
{

	public static bool isPalindrome(string s) { }
}
